"""
Console output helpers with cross-platform color support.

A slim, dependency-light subset of the formatting helpers used across the
project. Use these instead of bare ``print()`` for user-facing CLI output so
styling stays consistent; library code should keep diagnostics gated behind a
``verbose`` flag.
"""

from colorama import Fore, Style, init

# Initialize colorama for cross-platform color support (no-op on most *nix).
init(autoreset=True)


def print_success(message: str) -> None:
    """Print a success message in green (to stderr).

    Diagnostics go to stderr so command stdout stays pipe-clean (e.g. the
    ``smiles`` command emits only the SMILES string on stdout).
    """
    import sys
    print(f"{Fore.GREEN}{Style.BRIGHT}SUCCESS: {message}{Style.RESET_ALL}", file=sys.stderr)


def print_error(message: str) -> None:
    """Print an error message in red (to stderr)."""
    import sys
    print(f"{Fore.RED}{Style.BRIGHT}ERROR: {message}{Style.RESET_ALL}", file=sys.stderr)


def print_warning(message: str) -> None:
    """Print a warning message in yellow (to stderr)."""
    import sys
    print(f"{Fore.YELLOW}{Style.BRIGHT}WARNING: {message}{Style.RESET_ALL}", file=sys.stderr)


def print_info(message: str) -> None:
    """Print an informational message in cyan (to stderr)."""
    import sys
    print(f"{Fore.CYAN}INFO: {message}{Style.RESET_ALL}", file=sys.stderr)


def print_debug(message: str) -> None:
    """Print a debug message in dim magenta (to stderr)."""
    import sys
    print(f"{Fore.MAGENTA}{Style.DIM}DEBUG: {message}{Style.RESET_ALL}", file=sys.stderr)
