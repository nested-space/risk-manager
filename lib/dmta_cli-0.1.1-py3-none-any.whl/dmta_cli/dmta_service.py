"""
DMTA / Chemistry Connect service client.

Adapted (nearly verbatim) from governance-cli's DmtaService. Queries
AstraZeneca's Chemistry Connect "by-synonym" batch endpoint to resolve a
compound name/synonym into chemical structure data (SMILES) and alternative
synonyms.

This module depends only on ``httpx`` and ``pydantic``.

Authentication / configuration (environment variables):
    - DMTA_API_KEY: API authentication key.
    - DMTA_BATCH_SEARCH_ENDPOINT: Base URL for the DMTA service.

When these are not set, :func:`dmta_configured` returns False and callers should
skip DMTA (e.g. fall back to PubChem).
"""

import os
from typing import Any, Dict, List, Optional, Union

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from .console import print_debug, print_warning


class SearchProps(BaseModel):
    """Molecular formula and weight."""
    mf: Optional[str] = None
    mw: Optional[float] = None


class Structure(BaseModel):
    """Chemical structure representations returned by Chemistry Connect."""
    inchi: Optional[str] = None
    inchikey: Optional[str] = None
    molfile: Optional[str] = None
    smiles: Optional[str] = None
    search_props: Optional[SearchProps] = None


class DataItem(BaseModel):
    """Individual search result item."""
    score: Optional[float] = None
    cc_id: Optional[str] = None
    structure: Optional[Structure] = None


class BatchItem(BaseModel):
    """Batch search result for a single synonym query."""
    synonym: Optional[str] = None
    status: Optional[str] = None
    data: Optional[List[DataItem]] = None


class BatchSearchResponse(BaseModel):
    """Response from the DMTA batch synonym search endpoint."""
    model_config = ConfigDict(validate_by_name=True, validate_by_alias=True)
    batches: List[BatchItem] = Field(default_factory=list, validation_alias="batch")


def dmta_configured() -> bool:
    """Return True if both DMTA environment variables are set."""
    return bool(os.getenv("DMTA_API_KEY") and os.getenv("DMTA_BATCH_SEARCH_ENDPOINT"))


def collect_unique_synonyms(response: BatchSearchResponse) -> List[str]:
    """Collect unique synonyms from a batch response, preserving order."""
    seen = set()
    unique: List[str] = []
    for b in response.batches:
        s = b.synonym
        if s and s not in seen:
            seen.add(s)
            unique.append(s)
    return unique


def get_longest_smiles(data: Optional[BatchSearchResponse]) -> Optional[str]:
    """Extract the longest SMILES string from batch results.

    The longest SMILES is typically the most specific (stereochemistry,
    isotopes, etc.).
    """
    if not data:
        return None

    return max(
        (
            item.structure.smiles
            for batch in data.batches or []
            for item in (batch.data or [])
            if item.structure and item.structure.smiles
        ),
        key=len,
        default=None,
    )


async def search_by_synonym(
    synonym: str, *, timeout: float = 10.0, verbose: bool = False
) -> Optional[BatchSearchResponse]:
    """Search DMTA / Chemistry Connect for structure data by synonym.

    Args:
        synonym: Compound name or identifier to search for.
        timeout: Per-request timeout in seconds.
        verbose: If True, emit debug diagnostics to stderr.

    Returns:
        Parsed batch search response, or ``None`` if not configured or the
        response failed to validate.

    Raises:
        httpx.HTTPError: On network failure or non-2xx status (callers handle
            this to fall back to other resolvers).
    """
    api_key = os.getenv("DMTA_API_KEY")
    api_endpoint = os.getenv("DMTA_BATCH_SEARCH_ENDPOINT")
    if api_endpoint:
        api_endpoint = api_endpoint.rstrip("/")

    if not api_key or not api_endpoint:
        if verbose:
            print_warning("DMTA not configured (DMTA_API_KEY / DMTA_BATCH_SEARCH_ENDPOINT)")
        return None

    synonym_value = synonym.lower()
    url = f"{api_endpoint}/augmented/chemistry-connect/by-synonym-search/batch"

    if verbose:
        print_debug(f"DMTA search for {synonym_value!r} at {url}")

    body: Dict[str, Any] = {
        "synonyms": [synonym_value],
        "synonym_types": [
            "AZD",
            "AZ ID",
            "CAS ID",
            "Drug Name",
            "Systematic Name",
            "Reagent Name",
            "INN",
            "Trade Name",
        ],
        "sources": [],
        "term": "compound",
        "fields": {
            "includes": [
                "structure.inchi",
                "structure.inchikey",
                "structure.smiles",
                "structure.molfile",
                "structure.search_props.mf",
                "structure.search_props.mw",
            ]
        },
        "output_format": "raw",
    }
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "x-api-key": api_key,
    }

    async with httpx.AsyncClient() as client:
        r = await client.post(url, headers=headers, json=body, timeout=timeout)
        r.raise_for_status()
        try:
            return BatchSearchResponse.model_validate(r.json())
        except ValidationError:
            if verbose:
                print_warning("DMTA response failed schema validation")
            return None
