"""
Unified compound-name resolver.

Resolves a compound name to a canonical SMILES (plus any synonyms/aliases),
trying DMTA / Chemistry Connect first and falling back to public PubChem when
DMTA is unconfigured, unreachable, or returns no hit.

Both async (:func:`aresolve`, :func:`aresolve_many`) and sync (:func:`resolve`)
entry points are provided so this is convenient as a library and from the CLI.
"""

import asyncio
from dataclasses import dataclass, field
from typing import List

import httpx

from . import pubchem
from . import smiles as smiles_mod
from .console import print_warning
from .dmta_service import (
    collect_unique_synonyms,
    dmta_configured,
    get_longest_smiles,
    search_by_synonym,
)


@dataclass
class ResolveResult:
    """Result of resolving a compound name.

    Attributes:
        name: The original query name.
        smiles: Canonical SMILES, or ``None`` if unresolved.
        aliases: Synonyms returned by the resolver (may be empty).
        source: ``"dmta"``, ``"pubchem"``, or ``"none"``.
    """
    name: str
    smiles: str | None = None
    aliases: List[str] = field(default_factory=list)
    source: str = "none"

    @property
    def resolved(self) -> bool:
        """True if a SMILES was found."""
        return self.smiles is not None


async def _try_dmta(name: str, verbose: bool) -> ResolveResult | None:
    """Attempt DMTA resolution; return a result on hit, else ``None``."""
    try:
        response = await search_by_synonym(name, verbose=verbose)
    except httpx.HTTPError as exc:
        if verbose:
            print_warning(f"DMTA request failed for {name!r}: {exc}")
        return None
    if response is None:
        return None
    raw_smiles = get_longest_smiles(response)
    if not raw_smiles:
        return None
    canonical = smiles_mod.canonicalize(raw_smiles) or raw_smiles
    aliases = [a for a in collect_unique_synonyms(response) if a.lower() != name.lower()]
    return ResolveResult(name=name, smiles=canonical, aliases=aliases, source="dmta")


async def _try_pubchem(name: str, verbose: bool) -> ResolveResult | None:
    """Attempt PubChem resolution; return a result on hit, else ``None``."""
    try:
        hit = await pubchem.search_by_name(name, verbose=verbose)
    except httpx.HTTPError as exc:
        if verbose:
            print_warning(f"PubChem request failed for {name!r}: {exc}")
        return None
    if hit is None:
        return None
    raw_smiles, synonyms = hit
    canonical = smiles_mod.canonicalize(raw_smiles) or raw_smiles
    aliases = [a for a in synonyms if a.lower() != name.lower()]
    return ResolveResult(name=name, smiles=canonical, aliases=aliases, source="pubchem")


async def aresolve(
    name: str,
    *,
    use_dmta: bool = True,
    use_pubchem: bool = True,
    verbose: bool = False,
) -> ResolveResult:
    """Resolve a single compound name to a :class:`ResolveResult`.

    Tries DMTA first (when enabled and configured), then PubChem (when enabled).
    Always returns a result; check ``.resolved`` / ``.smiles`` for success.
    """
    name = name.strip()
    if not name:
        return ResolveResult(name=name)

    if use_dmta and dmta_configured():
        result = await _try_dmta(name, verbose)
        if result is not None:
            return result

    if use_pubchem:
        result = await _try_pubchem(name, verbose)
        if result is not None:
            return result

    return ResolveResult(name=name)


async def aresolve_many(
    names: List[str],
    *,
    use_dmta: bool = True,
    use_pubchem: bool = True,
    concurrency: int = 5,
    verbose: bool = False,
) -> List[ResolveResult]:
    """Resolve many names concurrently (bounded), preserving input order."""
    semaphore = asyncio.Semaphore(max(1, concurrency))

    async def _one(n: str) -> ResolveResult:
        async with semaphore:
            return await aresolve(
                n, use_dmta=use_dmta, use_pubchem=use_pubchem, verbose=verbose
            )

    return await asyncio.gather(*(_one(n) for n in names))


def resolve(
    name: str,
    *,
    use_dmta: bool = True,
    use_pubchem: bool = True,
    verbose: bool = False,
) -> ResolveResult:
    """Synchronous wrapper around :func:`aresolve` for library/CLI use."""
    return asyncio.run(
        aresolve(name, use_dmta=use_dmta, use_pubchem=use_pubchem, verbose=verbose)
    )
