"""
Bulk augmentation: a newline-delimited list of compound names -> CSV.

Reads a plain text file (one compound name per line), resolves each to a
canonical SMILES (and synonyms), and writes a CSV with the headers
``name,smiles,aliases``.

The ``aliases`` column joins synonyms with ``;;`` — the multi-character
delimiter the companion governance-cli bulk importer understands — so the output
round-trips back into that tool's ``material bulk-create``.
"""

import asyncio
import csv
from pathlib import Path
from typing import List, Optional, Union

from .console import print_info, print_success, print_warning
from .resolver import ResolveResult, aresolve_many

ALIAS_DELIMITER = ";;"
CSV_HEADERS = ["name", "smiles", "aliases"]


def read_names(path: Union[str, Path]) -> List[str]:
    """Read compound names from a text file (one per line).

    Blank lines and lines starting with ``#`` are ignored; surrounding
    whitespace is stripped.
    """
    text = Path(path).read_text(encoding="utf-8-sig")
    names: List[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        names.append(stripped)
    return names


def write_csv(results: List[ResolveResult], out_path: Union[str, Path]) -> None:
    """Write resolve results to a ``name,smiles,aliases`` CSV file."""
    with open(out_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(CSV_HEADERS)
        for result in results:
            aliases = ALIAS_DELIMITER.join(result.aliases) if result.aliases else ""
            writer.writerow([result.name, result.smiles or "", aliases])


async def aaugment_to_csv(
    in_path: Union[str, Path],
    out_path: Union[str, Path],
    *,
    use_dmta: bool = True,
    use_pubchem: bool = True,
    concurrency: int = 5,
    verbose: bool = False,
) -> List[ResolveResult]:
    """Async: read names, resolve them, write the CSV, return the results."""
    names = read_names(in_path)
    if not names:
        print_warning(f"No compound names found in {in_path}")
        write_csv([], out_path)
        return []

    print_info(f"Resolving {len(names)} compound(s)...")
    results = await aresolve_many(
        names,
        use_dmta=use_dmta,
        use_pubchem=use_pubchem,
        concurrency=concurrency,
        verbose=verbose,
    )
    write_csv(results, out_path)

    resolved = sum(1 for r in results if r.resolved)
    unresolved = [r.name for r in results if not r.resolved]
    print_success(f"Wrote {len(results)} row(s) to {out_path} ({resolved} resolved)")
    if unresolved:
        print_warning(f"Unresolved ({len(unresolved)}): {', '.join(unresolved)}")
    return results


def augment_to_csv(
    in_path: Union[str, Path],
    out_path: Optional[Union[str, Path]] = None,
    *,
    use_dmta: bool = True,
    use_pubchem: bool = True,
    concurrency: int = 5,
    verbose: bool = False,
) -> List[ResolveResult]:
    """Synchronous wrapper around :func:`aaugment_to_csv`.

    If ``out_path`` is omitted, it defaults to the input path with a ``.csv``
    suffix.
    """
    if out_path is None:
        out_path = Path(in_path).with_suffix(".csv")
    return asyncio.run(
        aaugment_to_csv(
            in_path,
            out_path,
            use_dmta=use_dmta,
            use_pubchem=use_pubchem,
            concurrency=concurrency,
            verbose=verbose,
        )
    )
