"""
dmta-cli: resolve compound names to SMILES, render molecule images, and
bulk-augment compound lists.

Library usage::

    import dmta_cli

    result = dmta_cli.resolve("aspirin")
    print(result.smiles)                      # canonical SMILES
    print(result.aliases, result.source)      # synonyms + which backend

    svg = dmta_cli.to_svg(result.smiles)
    dmta_cli.render(result.smiles, "png", "aspirin.png")

    dmta_cli.augment_to_csv("names.txt", "out.csv")
"""

from .augment import aaugment_to_csv, augment_to_csv, read_names, write_csv
from .render import render, to_png, to_svg
from .resolver import ResolveResult, aresolve, aresolve_many, resolve
from .smiles import canonicalize, is_valid

__version__ = "0.1.1"

__all__ = [
    "ResolveResult",
    "resolve",
    "aresolve",
    "aresolve_many",
    "canonicalize",
    "is_valid",
    "to_svg",
    "to_png",
    "render",
    "augment_to_csv",
    "aaugment_to_csv",
    "read_names",
    "write_csv",
    "__version__",
]
