#!/usr/bin/env python3
"""
dmta-cli command-line interface.

Subcommands:
    smiles   Resolve a compound name to a canonical SMILES string.
    image    Render a compound (name or SMILES) to an SVG/PNG image.
    augment  Bulk-resolve a text list of names into a name,smiles,aliases CSV.

Name resolution tries DMTA / Chemistry Connect first (when DMTA_API_KEY and
DMTA_BATCH_SEARCH_ENDPOINT are set) and falls back to public PubChem.
"""

import argparse
import sys
from pathlib import Path

from . import __version__
from .augment import augment_to_csv
from .console import print_error, print_info
from .render import VALID_FORMATS, render
from .resolver import resolve
from .smiles import is_valid


def _add_resolver_flags(parser: argparse.ArgumentParser) -> None:
    """Add backend toggles shared by name-resolving subcommands."""
    parser.add_argument(
        "--no-dmta", action="store_true", help="Skip the DMTA backend"
    )
    parser.add_argument(
        "--no-pubchem", action="store_true", help="Skip the PubChem fallback"
    )


def create_parser() -> argparse.ArgumentParser:
    """Build the top-level argument parser."""
    parser = argparse.ArgumentParser(
        prog="dmta-cli",
        description=(
            "Resolve compound names to SMILES, render molecule images, and "
            "bulk-augment compound lists."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  dmta-cli smiles aspirin
  dmta-cli image aspirin --format svg -o aspirin.svg
  dmta-cli image "CC(=O)Oc1ccccc1C(=O)O" --smiles --format png -o aspirin.png
  dmta-cli augment names.txt -o out.csv
""",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--verbose", action="store_true", help="Verbose diagnostics")

    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # smiles
    smiles_p = subparsers.add_parser(
        "smiles", help="Resolve a compound name to a canonical SMILES"
    )
    smiles_p.add_argument("name", help="Compound name to resolve")
    _add_resolver_flags(smiles_p)

    # image
    image_p = subparsers.add_parser(
        "image", help="Render a compound to an SVG/PNG image"
    )
    image_p.add_argument("query", help="Compound name, or a SMILES string with --smiles")
    image_p.add_argument(
        "--smiles", action="store_true", help="Treat QUERY as a SMILES string directly"
    )
    image_p.add_argument(
        "--format", "-f", choices=VALID_FORMATS, default="svg", help="Output format (default: svg)"
    )
    image_p.add_argument("--output", "-o", help="Output file path")
    image_p.add_argument("--width", type=int, default=400, help="Image width (default: 400)")
    image_p.add_argument("--height", type=int, default=300, help="Image height (default: 300)")
    _add_resolver_flags(image_p)

    # augment
    augment_p = subparsers.add_parser(
        "augment", help="Bulk-resolve a text list into a name,smiles,aliases CSV"
    )
    augment_p.add_argument("input", help="Text file with one compound name per line")
    augment_p.add_argument("--output", "-o", help="Output CSV path (default: input with .csv)")
    augment_p.add_argument(
        "--concurrency", type=int, default=5, help="Concurrent lookups (default: 5)"
    )
    _add_resolver_flags(augment_p)

    return parser


def _cmd_smiles(args: argparse.Namespace) -> int:
    result = resolve(
        args.name,
        use_dmta=not args.no_dmta,
        use_pubchem=not args.no_pubchem,
        verbose=args.verbose,
    )
    if not result.resolved:
        print_error(f"Could not resolve {args.name!r} to a SMILES string")
        return 1
    print(result.smiles)
    return 0


def _cmd_image(args: argparse.Namespace) -> int:
    if args.smiles:
        smiles = args.query
        if not is_valid(smiles):
            print_error(f"Invalid SMILES: {args.query!r}")
            return 1
        stem = "molecule"
    else:
        result = resolve(
            args.query,
            use_dmta=not args.no_dmta,
            use_pubchem=not args.no_pubchem,
            verbose=args.verbose,
        )
        if not result.resolved:
            print_error(f"Could not resolve {args.query!r} to a SMILES string")
            return 1
        smiles = result.smiles
        stem = args.query.replace(" ", "_")

    out_path = args.output or f"{stem}.{args.format}"
    try:
        render(smiles, args.format, out_path, width=args.width, height=args.height)
    except Exception as exc:
        print_error(str(exc))
        return 1
    print_info(f"Wrote {args.format.upper()} to {out_path}")
    return 0


def _cmd_augment(args: argparse.Namespace) -> int:
    in_path = Path(args.input)
    if not in_path.exists():
        print_error(f"Input file not found: {args.input}")
        return 1
    results = augment_to_csv(
        in_path,
        args.output,
        use_dmta=not args.no_dmta,
        use_pubchem=not args.no_pubchem,
        concurrency=args.concurrency,
        verbose=args.verbose,
    )
    # Exit non-zero only if nothing at all resolved (and there was input).
    if results and not any(r.resolved for r in results):
        return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    """Entry point: parse args and dispatch to a subcommand."""
    parser = create_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 1

    try:
        if args.command == "smiles":
            return _cmd_smiles(args)
        if args.command == "image":
            return _cmd_image(args)
        if args.command == "augment":
            return _cmd_augment(args)
    except KeyboardInterrupt:
        print_error("Cancelled by user")
        return 130
    except Exception as exc:  # pragma: no cover - top-level safety net
        print_error(str(exc))
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1

    parser.print_help()
    return 1


def cli_main() -> None:
    """Console-script entry point."""
    sys.exit(main())


if __name__ == "__main__":
    cli_main()
