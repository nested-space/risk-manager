"""
Render molecules from SMILES to image formats (SVG, PNG) using RDKit.

SVG has no system dependencies. PNG uses RDKit's Cairo backend
(``MolDraw2DCairo``, bundled in most RDKit wheels); if that is unavailable it
falls back to RDKit's Pillow-based ``Draw.MolToImage``.
"""

from pathlib import Path
from typing import Optional, Union

from rdkit import Chem
from rdkit.Chem.Draw import rdMolDraw2D

from . import smiles as smiles_mod

VALID_FORMATS = ("svg", "png")


def _mol_from_smiles(smiles: str) -> Chem.Mol:
    """Parse a SMILES string into an RDKit molecule, raising on failure."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES, cannot render: {smiles!r}")
    return mol


def to_svg(smiles: str, width: int = 400, height: int = 300) -> str:
    """Render ``smiles`` to an SVG document string."""
    mol = _mol_from_smiles(smiles)
    drawer = rdMolDraw2D.MolDraw2DSVG(width, height)
    drawer.DrawMolecule(mol)
    drawer.FinishDrawing()
    return str(drawer.GetDrawingText())


def to_png(smiles: str, width: int = 400, height: int = 300) -> bytes:
    """Render ``smiles`` to PNG bytes.

    Tries the Cairo backend first, then falls back to Pillow. Raises a clear
    error if neither backend is available.
    """
    mol = _mol_from_smiles(smiles)

    # Preferred: RDKit Cairo backend (no Pillow required).
    try:
        drawer = rdMolDraw2D.MolDraw2DCairo(width, height)
        drawer.DrawMolecule(mol)
        drawer.FinishDrawing()
        return bytes(drawer.GetDrawingText())
    except Exception:
        pass

    # Fallback: Pillow-based rendering.
    try:
        import io

        from rdkit.Chem.Draw import MolToImage

        image = MolToImage(mol, size=(width, height))
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        return buffer.getvalue()
    except Exception as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "PNG rendering requires RDKit's Cairo backend or Pillow; neither is "
            "available. Install Pillow ('pip install dmta-cli[png]') or use "
            "--format svg."
        ) from exc


def render(
    smiles: str,
    fmt: str = "svg",
    out_path: Optional[Union[str, Path]] = None,
    width: int = 400,
    height: int = 300,
) -> Union[str, bytes]:
    """Render ``smiles`` to ``fmt`` and optionally write it to ``out_path``.

    Args:
        smiles: SMILES string to render.
        fmt: ``"svg"`` or ``"png"``.
        out_path: If given, the rendered content is written here.
        width: Image width in pixels.
        height: Image height in pixels.

    Returns:
        The SVG text (str) or PNG bytes.
    """
    fmt = fmt.lower()
    if fmt not in VALID_FORMATS:
        raise ValueError(f"Unsupported format {fmt!r}; choose from {VALID_FORMATS}")
    if not smiles_mod.is_valid(smiles):
        raise ValueError(f"Invalid SMILES, cannot render: {smiles!r}")

    content: Union[str, bytes]
    if fmt == "svg":
        content = to_svg(smiles, width, height)
    else:
        content = to_png(smiles, width, height)

    if out_path is not None:
        path = Path(out_path)
        if isinstance(content, str):
            path.write_text(content, encoding="utf-8")
        else:
            path.write_bytes(content)

    return content
