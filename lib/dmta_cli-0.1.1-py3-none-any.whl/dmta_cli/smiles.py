"""
SMILES validation and canonicalization via RDKit.

Canonical SMILES is a unique string representation of a chemical structure, so
equivalent structures compare equal regardless of how they were written
(e.g. ``C=O`` and ``O=C`` both canonicalize to the same form). These helpers are
pure functions with no database or network dependency.
"""

from typing import Optional

from rdkit import Chem
from rdkit import RDLogger

# RDKit is noisy on stderr for invalid input; silence it (we report errors
# through our own console helpers / return values instead).
RDLogger.DisableLog("rdApp.*")


def is_valid(smiles: Optional[str]) -> bool:
    """Return True if ``smiles`` parses to a valid molecule.

    An empty/``None`` value is considered invalid (there is nothing to draw or
    canonicalize).
    """
    if not smiles:
        return False
    try:
        return Chem.MolFromSmiles(smiles) is not None
    except Exception:
        return False


def canonicalize(smiles: Optional[str]) -> Optional[str]:
    """Return the canonical form of ``smiles``, or ``None`` if invalid.

    Args:
        smiles: A SMILES string.

    Returns:
        Canonical SMILES, or ``None`` when the input is empty or unparseable.
    """
    if not smiles:
        return None
    try:
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            return None
        return str(Chem.MolToSmiles(molecule, canonical=True))
    except Exception:
        return None
