"""
Public PubChem PUG REST resolver (no API key required).

Used as a fallback when DMTA is unconfigured/unreachable or returns no hit.
Requires only internet access and ``httpx``.

PUG REST docs: https://pubchem.ncbi.nlm.nih.gov/docs/pug-rest
"""

from typing import List, Optional, Tuple
from urllib.parse import quote

import httpx

from .console import print_debug, print_warning

BASE_URL = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"

# Cap on synonyms pulled per compound; PubChem can return hundreds.
MAX_SYNONYMS = 10


async def _get_smiles(client: httpx.AsyncClient, name: str, timeout: float) -> Optional[str]:
    """Fetch a SMILES string for ``name`` from PubChem.

    Requests the stereochemistry-preserving SMILES property, falling back to the
    connectivity-only form. PubChem has renamed these keys over time
    (``IsomericSMILES``/``CanonicalSMILES`` -> ``SMILES``/``ConnectivitySMILES``),
    and the key in the response may differ from the one requested, so we accept
    any returned property whose name contains ``SMILES``.
    """
    encoded = quote(name, safe="")
    for prop in ("SMILES", "IsomericSMILES", "ConnectivitySMILES", "CanonicalSMILES"):
        url = f"{BASE_URL}/compound/name/{encoded}/property/{prop}/JSON"
        r = await client.get(url, timeout=timeout)
        if r.status_code == 404:
            return None
        if r.status_code >= 400:
            # An unknown property name yields a 400; try the next candidate.
            continue
        props = r.json().get("PropertyTable", {}).get("Properties", [])
        if not props:
            continue
        for key, value in props[0].items():
            if "SMILES" in key and value:
                return str(value)
    return None


async def _get_synonyms(
    client: httpx.AsyncClient, name: str, timeout: float
) -> List[str]:
    """Fetch up to ``MAX_SYNONYMS`` synonyms for ``name`` from PubChem."""
    encoded = quote(name, safe="")
    url = f"{BASE_URL}/compound/name/{encoded}/synonyms/JSON"
    r = await client.get(url, timeout=timeout)
    if r.status_code == 404:
        return []
    r.raise_for_status()
    info = r.json().get("InformationList", {}).get("Information", [])
    if not info:
        return []
    synonyms = info[0].get("Synonym", []) or []
    return synonyms[:MAX_SYNONYMS]


async def search_by_name(
    name: str, *, timeout: float = 10.0, verbose: bool = False
) -> Optional[Tuple[str, List[str]]]:
    """Resolve ``name`` to ``(smiles, synonyms)`` via PubChem, or ``None``.

    Returns ``None`` when PubChem has no compound for the name.

    Raises:
        httpx.HTTPError: On network failure or non-2xx status (other than 404).
    """
    if verbose:
        print_debug(f"PubChem search for {name!r}")
    async with httpx.AsyncClient() as client:
        smiles = await _get_smiles(client, name, timeout)
        if not smiles:
            if verbose:
                print_warning(f"PubChem: no SMILES for {name!r}")
            return None
        try:
            synonyms = await _get_synonyms(client, name, timeout)
        except httpx.HTTPError:
            # Synonyms are best-effort; a SMILES hit is still a success.
            synonyms = []
        return smiles, synonyms
